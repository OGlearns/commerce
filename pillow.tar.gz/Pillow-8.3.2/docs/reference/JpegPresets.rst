.. py:currentmodule:: PIL.JpegPresets

:py:mod:`~PIL.JpegPresets` Module
=================================

.. automodule:: PIL.JpegPresets

    .. data:: presets
        :type: dict

        A dictionary of all supported presets.
